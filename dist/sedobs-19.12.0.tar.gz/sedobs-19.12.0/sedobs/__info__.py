# -*- coding: utf-8 -*-
__author__ = "Romain Thomas"
__credits__ = "Romain Thomas"
__license__ = "GNU GPL v3"
__version__ = "0.2.0"
__maintainer__ = "Romain Thomas"
__email__ = "rthomas@eso.org"
__status__ = "Development"
__website__ = "https://astrom-tom.github.io/SEDobs/build/html/index.html" 
